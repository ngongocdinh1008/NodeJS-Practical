﻿using System.ComponentModel.DataAnnotations;

namespace Project___Sem3.Entity.Admin
{
    public class CandidateRequirement
    {
        [Key]
        public int CandidateRequirementId { get; set; }

        [Required]
        [MaxLength(5000)] // Để lưu trữ yêu cầu ứng viên
        public string Requirement { get; set; }

        // Khóa ngoại liên kết đến bảng Interview
        public int InterviewId { get; set; }

        // Navigation Property liên kết với bảng Interview
        public Interview Interview { get; set; }
    }
}
