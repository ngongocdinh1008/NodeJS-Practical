﻿using System.ComponentModel.DataAnnotations;

namespace Project___Sem3.Entity.Admin
{
    public class Interview
    {
        [Key] // Khóa chính tự động tăng
        public int InterviewId { get; set; }

        [Required]
        [MaxLength(200)] // Tiêu đề
        public string Title { get; set; }

        [MaxLength(200)] // Địa chỉ
        public string Address { get; set; }

        [Required] // Hạn kết thúc cuộc phỏng vấn
        public DateTime InterviewEndDate { get; set; }

        // Danh sách các mô tả công việc liên quan đến phỏng vấn này
        public ICollection<JobDescription> JobDescriptions { get; set; }

        // Danh sách các yêu cầu ứng viên liên quan đến phỏng vấn này
        public ICollection<CandidateRequirement> CandidateRequirements { get; set; }

        // Thêm thuộc tính để lưu danh sách các vị trí tuyển dụng
        public ICollection<Position> Positions { get; set; }

        // Thời gian làm việc
        [MaxLength(100)]
        public string WorkingHours { get; set; }

    }
}
