﻿using Microsoft.EntityFrameworkCore;
using Project___Sem3.Entity.Admin;

namespace Project___Sem3.Entity
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }
            
        // DbSet cho bảng Interview
        public DbSet<Interview> Interviews { get; set; }

        // DbSet cho bảng JobDescription (Mô tả công việc)
        public DbSet<JobDescription> JobDescriptions { get; set; }

        // DbSet cho bảng CandidateRequirement (Yêu cầu ứng viên)
        public DbSet<CandidateRequirement> CandidateRequirements { get; set; }

        // DbSet cho bảng Position (Vị trí tuyển dụng)
        public DbSet<Position> Positions { get; set; }

        // DbSet cho bảng User (Tài khoản người dùng)
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Quan hệ 1-n giữa Interview và JobDescription
            modelBuilder.Entity<Interview>()
                .HasMany(i => i.JobDescriptions)
                .WithOne(jd => jd.Interview)
                .HasForeignKey(jd => jd.InterviewId)
                .OnDelete(DeleteBehavior.Cascade);

            // Quan hệ 1-n giữa Interview và CandidateRequirement
            modelBuilder.Entity<Interview>()
                .HasMany(i => i.CandidateRequirements)
                .WithOne(cr => cr.Interview)
                .HasForeignKey(cr => cr.InterviewId)
                .OnDelete(DeleteBehavior.Cascade);

            // Quan hệ 1-n giữa Interview và Position
            modelBuilder.Entity<Interview>()
                .HasMany(i => i.Positions)
                .WithOne(p => p.Interview)
                .HasForeignKey(p => p.InterviewId)
                .OnDelete(DeleteBehavior.Cascade);

            base.OnModelCreating(modelBuilder);
        }
    }
}

