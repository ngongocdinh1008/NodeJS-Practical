﻿using Microsoft.AspNetCore.Mvc;
using Project___Sem3.Dto;
using Project___Sem3.Service;

namespace Project___Sem3.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class JobDescriptionController : ControllerBase
    {
        private readonly JobDescriptionService _jobDescriptionService;

        public JobDescriptionController(JobDescriptionService jobDescriptionService)
        {
            _jobDescriptionService = jobDescriptionService;
        }

        [HttpPut("update-job-description/{id}")]
        public async Task<IActionResult> UpdateJobDescription(int id, [FromBody] UpdateJobDescriptionDto updateDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                await _jobDescriptionService.UpdateJobDescriptionAsync(id, updateDto);
                return Ok("Job Description updated successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        // API để xóa JobDescription dựa trên JobDescriptionId
        [HttpDelete("delete-job-description/{id}")]
        public async Task<IActionResult> DeleteJobDescription(int id)
        {
            try
            {
                await _jobDescriptionService.DeleteJobDescriptionAsync(id);
                return Ok("Job Description deleted successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
