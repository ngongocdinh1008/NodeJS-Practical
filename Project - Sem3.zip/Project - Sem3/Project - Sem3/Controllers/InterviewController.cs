﻿using Microsoft.AspNetCore.Mvc;
using Project___Sem3.Dto;
using Project___Sem3.Service;

namespace Project___Sem3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InterviewController : ControllerBase
    {
        private readonly InterviewService _interviewService;

        public InterviewController(InterviewService interviewService)
        {
            _interviewService = interviewService;
        }

        [HttpPost("create-with-positions")]
        public async Task<IActionResult> CreateInterviewWithPositions([FromBody] InterviewDto interviewDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var interview = await _interviewService.CreateInterviewWithPositionsAsync(interviewDto);
            return Ok(interview); // Trả về thông tin Interview đã tạo cùng các Positions
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetInterview(int id)
        {
            try
            {
                var interview = await _interviewService.GetInterviewByIdAsync(id);
                if (interview == null)
                {
                    return NotFound();  
                }

                return Ok(interview);  
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
        // API để thêm JobDescription vào Interview đã tồn tại
        [HttpPost("add-job-description")]
        public async Task<IActionResult> AddJobDescription([FromBody] JobDescriptionDto jobDescriptionDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            await _interviewService.AddJobDescriptionAsync(jobDescriptionDto);
            return Ok("Job Description added successfully");
        }

        // API để thêm CandidateRequirement vào Interview đã tồn tại
        [HttpPost("add-candidate-requirement")]
        public async Task<IActionResult> AddCandidateRequirement([FromBody] CandidateRequirementDto candidateRequirementDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            await _interviewService.AddCandidateRequirementAsync(candidateRequirementDto);
            return Ok("Candidate Requirement added successfully");
        }
        // API để thêm Position vào Interview đã tồn tại
        [HttpPost("add-position")]
        public async Task<IActionResult> AddPosition([FromBody] PositionDto positionDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            await _interviewService.AddPositionAsync(positionDto);
            return Ok("Position added successfully");
        }
        // API để cập nhật thông tin Interview
        [HttpPut("update-interview/{id}")]
        public async Task<IActionResult> UpdateInterview(int id, [FromBody] UpdateInterviewDto updateDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                await _interviewService.UpdateInterviewAsync(id, updateDto);
                return Ok("Interview updated successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        // API để xóa Interview và các bảng liên quan
        [HttpDelete("delete-interview/{id}")]
        public async Task<IActionResult> DeleteInterview(int id)
        {
            try
            {
                await _interviewService.DeleteInterviewAsync(id);
                return Ok("Interview and related data deleted successfully");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
