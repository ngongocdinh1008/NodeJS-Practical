﻿using Project___Sem3.Dto;
using Project___Sem3.Entity;

namespace Project___Sem3.Service
{
    public class CandidateRequirementService
    {
        private readonly AppDbContext _context;

        public CandidateRequirementService(AppDbContext context)
        {
            _context = context;
        }

        public async Task UpdateCandidateRequirementAsync(int candidateRequirementId, UpdateCandidateRequirementDto updateDto)
        {
            var candidateRequirement = await _context.CandidateRequirements.FindAsync(candidateRequirementId);
            if (candidateRequirement == null) throw new Exception("Candidate Requirement not found");

            // Kiểm tra sự khác biệt trước khi cập nhật
            if (candidateRequirement.Requirement != updateDto.Requirement)
            {
                candidateRequirement.Requirement = updateDto.Requirement;
                await _context.SaveChangesAsync();
            }
            else
            {
                throw new Exception("No changes detected");
            }
        }
        // Phương thức xóa CandidateRequirement dựa trên CandidateRequirementId
        public async Task DeleteCandidateRequirementAsync(int candidateRequirementId)
        {
            var candidateRequirement = await _context.CandidateRequirements.FindAsync(candidateRequirementId);
            if (candidateRequirement == null)
            {
                throw new Exception("Candidate Requirement not found");
            }

            _context.CandidateRequirements.Remove(candidateRequirement);
            await _context.SaveChangesAsync();
        }
    }
}
