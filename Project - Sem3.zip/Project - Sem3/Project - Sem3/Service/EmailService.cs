﻿using System.Net.Mail;
using System.Net;

public class EmailService
{
    private readonly IConfiguration _configuration;

    public EmailService(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public async Task SendEmailAsync(string toEmail, string subject, string body)
    {
        var smtpClient = new SmtpClient(_configuration["MailSettings:SmtpServer"])
        {
            Port = int.Parse(_configuration["MailSettings:Port"]),
            Credentials = new NetworkCredential(
                _configuration["MailSettings:Username"],
                _configuration["MailSettings:Password"]),
            EnableSsl = true,
        };

        var mailMessage = new MailMessage
        {
            From = new MailAddress(_configuration["MailSettings:SenderEmail"], _configuration["MailSettings:SenderName"]),
            Subject = subject,
            Body = body,
            IsBodyHtml = true,
        };
        mailMessage.To.Add(toEmail);

        try
        {
            await smtpClient.SendMailAsync(mailMessage);
        }
        catch (Exception ex)
        {
            throw new Exception($"Không thể gửi email. Lỗi chi tiết: {ex.Message}");
        }
    }
}
