﻿using Project___Sem3.Dto;
using Project___Sem3.Entity;

namespace Project___Sem3.Service
{
    public class JobDescriptionService
    {
        private readonly AppDbContext _context;

        public JobDescriptionService(AppDbContext context)
        {
            _context = context;
        }

        public async Task UpdateJobDescriptionAsync(int jobDescriptionId, UpdateJobDescriptionDto updateDto)
        {
            var jobDescription = await _context.JobDescriptions.FindAsync(jobDescriptionId);
            if (jobDescription == null) throw new Exception("Job Description not found");

            // Kiểm tra sự khác biệt trước khi cập nhật
            if (jobDescription.Description != updateDto.Description)
            {
                jobDescription.Description = updateDto.Description;
                await _context.SaveChangesAsync();
            }
            else
            {
                throw new Exception("No changes detected");
            }
        }
        // Phương thức xóa JobDescription dựa trên JobDescriptionId
        public async Task DeleteJobDescriptionAsync(int jobDescriptionId)
        {
            var jobDescription = await _context.JobDescriptions.FindAsync(jobDescriptionId);
            if (jobDescription == null)
            {
                throw new Exception("Job Description not found");
            }

            _context.JobDescriptions.Remove(jobDescription);
            await _context.SaveChangesAsync();
        }
    }
}
