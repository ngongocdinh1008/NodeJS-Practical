﻿using System.ComponentModel.DataAnnotations;

namespace Project___Sem3.Dto
{
    public class UpdatePositionDto
    {
        [Required]
        [MaxLength(100)]
        public string PositionTitle { get; set; }

        [Required]
        public decimal Salary { get; set; }

        [Required]
        public int ExperienceRequired { get; set; }

        [MaxLength(50)]
        public string Rank { get; set; }

        [MaxLength(50)]
        public string JobType { get; set; }

        [MaxLength(100)]
        public string GenderRequirement { get; set; }
    }
}
