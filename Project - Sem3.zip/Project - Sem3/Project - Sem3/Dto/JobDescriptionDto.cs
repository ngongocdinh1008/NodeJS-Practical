﻿namespace Project___Sem3.Dto
{
    public class JobDescriptionDto
    {
        public string Description { get; set; }
        public int InterviewId { get; set; }
    }
}
