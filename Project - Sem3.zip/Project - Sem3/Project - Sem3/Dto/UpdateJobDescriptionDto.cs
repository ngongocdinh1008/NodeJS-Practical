﻿using System.ComponentModel.DataAnnotations;

namespace Project___Sem3.Dto
{
    public class UpdateJobDescriptionDto
    {
        [Required]
        [MaxLength(500)]
        public string Description { get; set; }
    }
}
