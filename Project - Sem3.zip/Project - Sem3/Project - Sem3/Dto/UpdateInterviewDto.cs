﻿using System.ComponentModel.DataAnnotations;

namespace Project___Sem3.Dto
{
    public class UpdateInterviewDto
    {
        [Required]
        [MaxLength(200)]
        public string Title { get; set; }

        [Required]
        [MaxLength(200)]
        public string Address { get; set; }

        [Required]
        public DateTime InterviewEndDate { get; set; }

        [Required]
        [MaxLength(100)]
        public string WorkingHours { get; set; }
    }
}
