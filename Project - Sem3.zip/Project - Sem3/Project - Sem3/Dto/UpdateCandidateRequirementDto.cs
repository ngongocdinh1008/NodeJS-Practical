﻿using System.ComponentModel.DataAnnotations;

namespace Project___Sem3.Dto
{
    public class UpdateCandidateRequirementDto
    {
        [Required]
        [MaxLength(500)]
        public string Requirement { get; set; }
    }
}
