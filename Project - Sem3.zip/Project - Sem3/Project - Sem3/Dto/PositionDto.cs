﻿using System.ComponentModel.DataAnnotations;

namespace Project___Sem3.Dto
{
    public class PositionDto
    {
        [Required]
        [MaxLength(100)]
        public string PositionTitle { get; set; }

        [Required]
        public decimal Salary { get; set; }

        [Required]
        public int ExperienceRequired { get; set; }

        public string Rank { get; set; }
        public string JobType { get; set; }
        public string GenderRequirement { get; set; }
        public int InterviewId { get; set; }
    }
}
