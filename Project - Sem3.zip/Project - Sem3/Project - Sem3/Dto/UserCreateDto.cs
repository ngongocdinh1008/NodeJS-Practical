﻿using System.ComponentModel.DataAnnotations;

namespace Project___Sem3.Dto
{
    public class UserCreateDto
    {
        [Required]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Username phải có độ dài từ 3 đến 50 ký tự.")]
        [RegularExpression(@"^[a-zA-Z0-9]+$", ErrorMessage = "Username chỉ chứa ký tự chữ và số.")]
        public string Username { get; set; }

        [Required]
        [EmailAddress(ErrorMessage = "Email không hợp lệ.")]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [StringLength(100, MinimumLength = 6, ErrorMessage = "Password phải có ít nhất 6 ký tự.")]
        public string Password { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Mật khẩu nhập lại không khớp.")]
        public string ConfirmPassword { get; set; }
    }
}
