﻿namespace Project___Sem3.Dto
{
    public class CandidateRequirementDto
    {
        public string Requirement { get; set; }
        public int InterviewId { get; set; }
    }
}
